const express = require('express');
const Redis = require('ioredis');

// Create an instance of the express app
const app = express();

// Create a new Redis client
const redis = new Redis(); // Connects to localhost:6379 by default

// Initialize an empty list or key to represent no items in the list
const initializeTodoList = async () => {
    try {
      const isInitialized = await redis.get('todo_initialized');
      
      if (isInitialized) {
        console.log('Tasks list is already initialized.');
      } else {
        console.log('Initializing...');
        await redis.set('todo_initialized', 'true'); 
      }
    } catch (err) {
      console.error(err);
    }
  };
  
//　initialize todo  
initializeTodoList();  

// Load Route
app.get("/load", async(req, res) => {
    const tasks = await redis.lrange('tasks', 0, -1); 
    res.json(tasks);
})

// Save Route
app.post("/save", async(req,res) => {
    const { todoList } = req.body;
    const response = { status: "save successful"};
    redis.ltrim('tasks', 0, -1);
    await redis.rpush('tasks', ...todoList);
    res.send(response);
})

// Clear Route
app.get("/clear", async(req,res) => {
    const response = { status: "clear successful"};
    redis.ltrim('tasks', 0, -1);
    res.json(response);
})

// Start the Express server
app.listen(3001, () => {
  console.log('Server is running on http://localhost:3001');
});
