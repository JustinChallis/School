import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Alert } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import axios from 'axios';

const App = () => {
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([]);
  const [editingId, setEditingId] = useState(null); 
  const [initialized, setInitialized] = useState(false);

  const backendUrl = 'http://localhost:3001';

  // Load tasks from the backend
  const restoreTasks = async () => {
    try {
      const response = await axios.get(`${backendUrl}/load`);
      setTasks(response.data);
    } catch (error) {
      console.error('Error loading tasks:', error);
    }
  };

// Save a new task to the backend
  const clearTasks = async () => {
    if (task.trim()) {
      try {
        await axios.post(`${backendUrl}/clear`, { task });
        setTask('');
        loadTasks(); // Reload tasks after adding
      } catch (error) {
        console.error('Error clearing tasks:', error);
      }
    }
  };

  // Save a new task to the backend
  const saveTasks = async () => {
    if (task.trim()) {
      try {
        await axios.post(`${backendUrl}/save`, { task });
        setTask('');
        loadTasks(); // Reload tasks after adding
      } catch (error) {
        console.error('Error saving task:', error);
      }
    }
  };

  const addTask = () => {
    if (task.trim()) {
      setTasks([...tasks, { id: tasks.length.toString(), text: task, completed: false }]);
      setTask('');
    }
  };

  const toggleTaskCompletion = (id) => {
    setTasks(tasks.map((task) => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter((task) => task.id !== id));
  };

  // Edit a task
  const editTask = (id) => {
    const taskToEdit = tasks.find((task) => task.id === id);
    setTask(taskToEdit.text); 
    setEditingId(id); 
  };

  // Save edited task
  const saveTask = () => {
    if (task.trim()) {
      setTasks(tasks.map((taskItem) => 
        taskItem.id === editingId ? { ...taskItem, text: task } : taskItem
      ));
      setTask('');
      setEditingId(null); 
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>To-Do List</Text>

      <TextInput
        style={styles.input}
        placeholder="Enter task"
        value={task} 
        onChangeText={setTask}
      />
      
      <TouchableOpacity style={styles.addButton} onPress={editingId ? saveTask : addTask}>
        <Text style={styles.addButtonText}>{editingId ? 'Edit' : 'Add'}</Text>
      </TouchableOpacity>

      <View style={styles.actionButtons}>
        <TouchableOpacity style={styles.actionButton} onPress={() => saveTasks()}>
          <Text style={styles.actionButtonText}>Save</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionButton} onPress={() => restoreTasks()}>
          <Text style={styles.actionButtonText}>Restore</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionButton} onPress={() => clearTasks()}>
          <Text style={styles.actionButtonText}>Clear</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={tasks}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={[styles.task, item.completed && styles.completedTask]}>
            <Text 
              style={[styles.taskText, item.completed && styles.completedTaskText]}
              onPress={() => toggleTaskCompletion(item.id)}
            >
              {item.text}
            </Text>
            <TouchableOpacity onPress={() => editTask(item.id)}>
              <Icon name="create" size={24} color="green" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => deleteTask(item.id)}>
              <Icon name="trash" size={24} color="red" />
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000', 
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 32,
    color: '#32CD32', 
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    padding: 10,
    marginBottom: 20,
    borderColor: '#32CD32', 
    borderWidth: 1,
    color: '#fff', 
    backgroundColor: '#333', 
    borderRadius: 5,
  },
  addButton: {
    backgroundColor: '#32CD32', 
    padding: 10,
    borderRadius: 5,
    marginBottom: 20,
  },
  addButtonText: {
    color: '#000', 
    fontWeight: 'bold',
    textAlign: 'center',
  },
  task: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#222', 
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  completedTask: {
    backgroundColor: '#555', 
  },
  taskText: {
    color: '#fff', 
    fontSize: 18,
  },
  completedTaskText: {
    textDecorationLine: 'line-through',
    color: '#808080', 
  },
  actionButton: {
    backgroundColor: '#ffffff', 
    padding: 10,
    borderRadius: 5,
    width: 80,
    alignItems: 'center',
  },
  actionButtonText: {
    color: '#000',
    fontWeight: 'bold',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    width: '100%',
    marginBottom: 20,
  },
});

export default App;
