const sqlite3 = require('sqlite3').verbose();

// Open database (or create it if it doesn't exist)
const db = new sqlite3.Database('./database.db', (err) => {
  if (err) {
    console.error("Error opening the database", err.message);
  } else {
    console.log("Connected to the SQLite database.");
  }
});

// Create a table if it doesn't exist
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS books (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      isbn TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      author TEXT NOT NULL,
      desc TEXT,
      genre TEXT
    )
  `);
});

module.exports = db;