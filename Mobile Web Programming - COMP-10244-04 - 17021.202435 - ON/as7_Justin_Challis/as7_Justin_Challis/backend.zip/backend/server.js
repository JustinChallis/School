const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db');
const cors = require('cors');
const app = express();
const port = 3001;


app.use(cors());
// Middleware to parse JSON bodies
app.use(bodyParser.json());

// CREATE: Add a new Book
app.post('/books', (req, res) => {
  const { isbn, title, author, desc, genre } = req.body;
  
  if (!isbn || !title || !author) {
    return res.status(400).json({ message: "isbn, title, and author are required fields." });
  }

  const query = 'INSERT INTO books (isbn, title, author, desc, genre) VALUES (?, ?, ?, ?, ?)';
  db.run(query, [isbn, title, author, desc, genre], function(err) {
    if (err) {
      return res.status(500).json({ message: err.message });
    }
    res.status(201).json({ id: this.lastID, isbn, title, author, desc, genre });
  });
});

// READ: Get all books
app.get('/books', (req, res) => {
  const query = 'SELECT * FROM books';
  db.all(query, [], (err, rows) => {
    if (err) {
      return res.status(500).json({ message: err.message });
    }
    res.json(rows);
  });
});

// READ: Get a Book by ID
app.get('/books/:id', (req, res) => {
  const { id } = req.params;
  const query = 'SELECT * FROM books WHERE id = ?';
  
  db.get(query, [id], (err, row) => {
    if (err) {
      return res.status(500).json({ message: err.message });
    }
    if (!row) {
      return res.status(404).json({ message: "Book not found." });
    }
    res.json(row);
  });
});

// UPDATE: Update Book details
app.put('/books/:id', (req, res) => {
  const { id } = req.params;
  const { isbn, title, author, desc, genre } = req.body;
  
  if (!isbn || !title || !author) {
    return res.status(400).json({ message: "isbn, title, and author are required." });
  }

  const query = 'UPDATE books SET isbn = ?, title = ?, author = ?, desc = ?, genre = ? WHERE id = ?';
  db.run(query, [isbn, title, author, desc, genre, id], function(err) {
    if (err) {
      return res.status(500).json({ message: err.message });
    }
    if (this.changes === 0) {
      return res.status(404).json({ message: "Book not found." });
    }
    res.json({ message: "Book updated successfully." });
  });
});

// DELETE: Delete a Book
app.delete('/books/:id', (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM books WHERE id = ?';

  db.run(query, [id], function(err) {
    if (err) {
      return res.status(500).json({ message: err.message });
    }
    if (this.changes === 0) {
      return res.status(404).json({ message: "Book not found." });
    }
    res.json({ message: "Book deleted successfully." });
  });
});

// DELETE: Delete all books
app.delete('/books', (req, res) => {
  const { id } = req.params;
  const query = 'DELETE FROM books';

  db.run(query, id, function(err) {
    if (err) {
      return res.status(500).json({ message: err.message });
    }
    if (this.changes === 0) {
      return res.status(404).json({ message: "Books could not be deleted" });
    }
    res.json({ message: "Books deleted successfully." });
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
