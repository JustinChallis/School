import React, { useState } from 'react';
import { Text, TextInput, Button, StyleSheet, ScrollView, Alert, SafeAreaView, View } from 'react-native';
import { useFonts } from 'expo-font';
import axios from 'axios';

export default function TabTwoScreen() {
  const [title, setTitle] = useState('');
  const [isbn, setIsbn] = useState('');
  const [author, setAuthor] = useState('');
  const [description, setDescription] = useState('');
  const [genre, setGenre] = useState('');
  const [responseMessage, setResponseMessage] = useState('');
  
  const handleEdit = () => {
    if (!title || !isbn || !author) {
      Alert.alert('Error', 'fill required fields!');
      return;
    }
    const data = {
      isbn : isbn,
      title : title,
      author : author,
      desc : description,
      genre : genre,
    }
    
    
    axios
      .put('http://localhost:3001/books/', data)
      .then((response) => {
      // Handle success
      setResponseMessage('Success: ' + JSON.stringify(response.data));
    }).catch((error) => {
      // Handle error
      setResponseMessage('Error: ' + error.message);
    });

    Alert.alert('Success', 'Book added successfully!');
    setTitle('');
    setIsbn('');
    setAuthor('');
    setDescription('');
    setGenre('');
  };
  
  const handleSubmit = () => {
    if (!title || !isbn || !author) {
      Alert.alert('Error', 'All fields are required!');
      return;
    }
    const data = {
      isbn : isbn,
      title : title,
      author : author,
      desc : description,
      genre : genre,
    }

    axios
      .post('http://localhost:3001/books', data)
      .then((response) => {
      // Handle success
      setResponseMessage('Success: ' + JSON.stringify(response.data));
    }).catch((error) => {
      // Handle error
      setResponseMessage('Error: ' + error.message);
    });

    Alert.alert('Success', 'Book added successfully!');
    setTitle('');
    setIsbn('');
    setAuthor('');
    setDescription('');
    setGenre('');
  };
    return (
      <SafeAreaView style={styles.container}>
        {/* Fixed Top Bar */}
        <View style={styles.topBar}>
            <Text style={styles.title}>Bookollekt</Text>
          </View>
        <ScrollView contentContainerStyle={styles.content}>
          <Text style={styles.formTitle}></Text>
  
          <TextInput style={styles.input} placeholder="ISBN *" value={isbn} onChangeText={setIsbn} keyboardType="numeric" />
          <TextInput style={styles.input} placeholder="Title *" value={title} onChangeText={setTitle} />
          <TextInput style={styles.input} placeholder="Author *" value={author} onChangeText={setAuthor} />
          <TextInput style={styles.input} placeholder="Description" value={description} onChangeText={setDescription} keyboardType="numeric" />
          <TextInput style={styles.input} placeholder="Genre" value={genre} onChangeText={setGenre} />
          <View style={styles.buttonContainer}>
            <Button title="Add Book" onPress={handleSubmit} />
          </View>
          {responseMessage ? (
          <Text style={styles.response}>{responseMessage}</Text>
        ) : null}
        </ScrollView>
      </SafeAreaView>
    );
}

const styles = StyleSheet.create({
  buttonContainer: {
    flexDirection: 'row', // Align buttons side by side
    justifyContent: 'space-evenly', // Distribute space evenly between buttons
    padding: 10, // Padding around the container
  },
  topBar: {
    height: 80, // Height of the top bar
    backgroundColor: '#333', // Customize color as needed
    justifyContent: 'center', // Centers content vertically
    alignItems: 'center', // Centers content horizontally
    position: 'absolute', // Fix the bar to the top
    top: 0, // Ensures it's positioned at the top of the screen
    left: 0,
    right: 0,
    zIndex: 1, // Makes sure it's above other components
  },
  title: {
    fontFamily: 'Cinzel',
    fontSize: 32, // Large font size
    fontWeight: 'bold',
    color: '#fff', // White color for the title
  },
  container: {
    flex: 1,
  },
  content: {
    paddingTop: 100, // Space for the fixed top bar
    padding: 20,
  },
  headerImage: {
    color: '#808080',
    bottom: -90,
    left: -35,
    position: 'absolute',
  },
  titleContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  form: {
    paddingBottom: 20,
  },
  formTitle: {
    fontSize: 24,
    fontFamily: 'Cinzel',
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    height: 50,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 15,
    paddingLeft: 10,
    fontSize: 16,
  },  
  response: {
    marginTop: 20,
    fontSize: 16,
    color: 'green',
  },
});
