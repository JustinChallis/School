import React, { useEffect, useState } from 'react';
import { MaterialIcons } from '@expo/vector-icons';
import { View, Text, StyleSheet, StatusBar,TouchableOpacity, SafeAreaView, ScrollView,  ActivityIndicator } from 'react-native';
import axios from 'axios';
import { Table } from '@/components/Table';
import { QuickSearchBar } from '@/components/QuickSearchBar';
export default function App() {

  return (
    <SafeAreaView style={styles.container}>
      {/* StatusBar for iOS compatibility */}
      <StatusBar barStyle="dark-content" />

      {/* Fixed Top Bar */}
      <View style={styles.topBar}>
        <Text style={styles.title}>Bookollekt</Text>
      </View>

      {/* Main Content */}
      <View style={styles.content}>
      <QuickSearchBar></QuickSearchBar>
      <Table />
    </View>
      
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  topBar: {
    height: 80, // Height of the top bar
    backgroundColor: '#333', // Customize color as needed
    justifyContent: 'center', // Centers content vertically
    alignItems: 'center', // Centers content horizontally
    position: 'absolute', // Fix the bar to the top
    top: 0, // Ensures it's positioned at the top of the screen
    left: 0,
    right: 0,
    zIndex: 1, // Makes sure it's above other components
  },
  title: {
    fontFamily: 'Cinzel',
    fontSize: 32, // Large font size
    fontWeight: 'bold',
    color: '#fff', // White color for the title
  },
  content: {
    paddingTop: 100, // Space for the fixed top bar
    padding: 20,
  },
  contentText: {
    fontSize: 18,
    color: '#333',
  },
  icon: {
    marginHorizontal: 10,
  },
  button: {
    alignItems: 'center',
    backgroundColor: '#DDDDDD',
    padding: 10,
  },
});
