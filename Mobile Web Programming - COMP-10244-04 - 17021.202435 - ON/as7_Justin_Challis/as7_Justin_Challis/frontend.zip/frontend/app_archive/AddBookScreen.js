import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, ScrollView, Alert, SafeAreaView } from 'react-native';
import { useFonts } from 'expo-font';
import axios from 'axios';

export default function AddBookScreen(item) {
  let [fontsLoaded] = useFonts({
    'Cinzel': require('../assets/fonts/Cinzel-VariableFont_wght.ttf'),
  });

  if (!fontsLoaded) {
    return <Text>Loading Fonts...</Text>;
  }

  const [title, setTitle] = useState(item == null ? '' : item.title);
  const [isbn, setIsbn] = useState(item == null ? '' : item.isbn);
  const [author, setAuthor] = useState(item == null ? '' : item.author);
  const [description, setDescription] = useState(item == null ? '' : item.description);
  const [genre, setGenre] = useState(item == null ? '' : item.genre);
  const [responseMessage, setResponseMessage] = useState('');

  const handleSubmit = () => {

    if (!title || !isbn || !author) {
      Alert.alert('Error', 'All fields are required!');
      return;
    }
    const data = {
      isbn : isbn,
      title : title,
      author : author,
      desc : description,
      genre : genre,
    }

    axios
      .post('http://localhost:3001/books', data)
      .then((response) => {
      // Handle success
      setResponseMessage('Success: ' + JSON.stringify(response.data));
    }).catch((error) => {
      // Handle error
      setResponseMessage('Error: ' + error.message);
    });

    Alert.alert('Success', 'Book added successfully!');
    setTitle('');
    setIsbn('');
    setAuthor('');
    setDescription('');
    setGenre('');
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.form}>
        <Text style={styles.formTitle}>Add a New Book</Text>

        <TextInput style={styles.input} placeholder="ISBN *" value={isbn} onChangeText={setIsbn} keyboardType="numeric" />
        <TextInput style={styles.input} placeholder="Title *" value={title} onChangeText={setTitle} />
        <TextInput style={styles.input} placeholder="Author *" value={author} onChangeText={setAuthor} />
        <TextInput style={styles.input} placeholder="Description" value={description} onChangeText={setDescription} keyboardType="numeric" />
        <TextInput style={styles.input} placeholder="Genre" value={genre} onChangeText={setGenre} />

        <Button title="Add Book" onPress={handleSubmit} />
        {responseMessage ? (
        <Text style={styles.response}>{responseMessage}</Text>
      ) : null}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 40,
    paddingHorizontal: 20,
  },
  form: {
    paddingBottom: 20,
  },
  formTitle: {
    fontSize: 24,
    fontFamily: 'Cinzel',
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    height: 50,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 15,
    paddingLeft: 10,
    fontSize: 16,
  },  
  response: {
    marginTop: 20,
    fontSize: 16,
    color: 'green',
  },
});
