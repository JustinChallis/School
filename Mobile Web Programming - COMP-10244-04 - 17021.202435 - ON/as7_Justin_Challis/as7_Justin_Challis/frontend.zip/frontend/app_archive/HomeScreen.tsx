import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, StatusBar, ScrollView, ActivityIndicator  } from 'react-native';
import axios from 'axios';
import { MaterialIcons } from '@expo/vector-icons';

// Define a type for the user data
interface Book {
    id: number;
    isbn: string;
    title: string;
    author: string;
    desc: string;
    genre: string;
  }

  const handleEdit = (item : Book) => {
        // TODO
  };
  
  const handleDeleteAll = () => {
    axios
    .delete('http://localhost:3001/books/')
    .then((response) => {
  }).catch((error) => {
    // Handle error
    console.log(error);
  });
  
  };
  
  const handleDelete = ({id}: Book) => {
    axios
    .delete('http://localhost:3001/books/'+id)
    .then((response) => {
  }).catch((error) => {
    // Handle error
    console.log(error);
  });
  
  };
  
  

// HomeScreen Component
export default function HomeScreen({ navigation }) {
    const [data, setData] = useState<Book[]>([]);
    const [loading, setLoading] = useState(true);

    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:3001/books');
        setData(response.data); // Set data in state
      } catch (err) {
        console.error(err);
      }
    };

    useEffect(() => {
      fetchData(); // Initial fetch
      setLoading(false);
    // Set interval to fetch every 0.5 seconds
    const intervalId = setInterval(fetchData, 500); // Regular interval
    
    // Cleanup the interval on component unmount
    return () => clearInterval(intervalId);
    }, []);
    
    
    if (loading) {
      return <ActivityIndicator size="large" color="#0000ff" style={styles.centered} />;
    }

    return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" />

      {/* Fixed Top Bar */}
      <View style={styles.topBar}>
        <Text style={styles.title}>Bookollekt</Text>
      </View>
      <ScrollView contentContainerStyle={styles.tableContainer}>
        <View style={styles.tableRow}>
          <Text style={styles.tableHeader}>ID</Text>
          <Text style={styles.tableHeader}>ISBN</Text>
          <Text style={styles.tableHeader}>Title</Text>
          <Text style={styles.tableHeader}>Author</Text>
          <Text style={styles.tableHeader}>Description</Text>
          <Text style={styles.tableHeader}>Genre</Text>
        </View>

        {data.map((item) => (
          <View key={item.id} style={styles.tableRow}>
            <Text style={styles.tableCell}>{item.id}</Text>
            <Text style={styles.tableCell}>{item.isbn}</Text>
            <Text style={styles.tableCell}>{item.title}</Text>
            <Text style={styles.tableCell}>{item.author}</Text>
            <Text style={styles.tableCell}>{item.desc}</Text>
            <Text style={styles.tableCell}>{item.genre}</Text>
            <View style={styles.actions}>
            <TouchableOpacity onPress={() => handleEdit(item)}>
              <MaterialIcons  name="edit" size={24} color="blue" style={styles.icon} />
            </TouchableOpacity>

            <TouchableOpacity onPress={() => handleDelete(item)}>
              <MaterialIcons  name="delete" size={24} color="red" style={styles.icon} />
            </TouchableOpacity>
          </View>

          </View>
                    
        ))}
            
            <View style={styles.container}>
                    <TouchableOpacity style={styles.navButton} onPress={handleDeleteAll}>
                      <Text style={styles.navButtonText}>Delete All</Text>
                    </TouchableOpacity>
                  </View>
      </ScrollView>


      {/* Fixed Bottom Navigation Bar */}
      <View style={styles.bottomNav}>
        <TouchableOpacity
          style={styles.navButton}
          onPress={() => navigation.navigate('Home')}>
          <Text style={styles.navButtonText}>Home</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.navButton}
          onPress={() => navigation.navigate('AddBook')}>
          <Text style={styles.navButtonText}>Add</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 50,
    paddingHorizontal: 20,
    },
  topBar: {
    height: 120,
    backgroundColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1,
  },
  title: {
    fontFamily: 'Cinzel',
    fontSize: 64,
    fontWeight: 'bold',
    color: '#fff',
  },
  content: {
    paddingTop: 140,
    paddingBottom: 20,
    alignItems: 'center',
  },
  bottomNav: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 70,
    backgroundColor: '#333',
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  navButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#333',
    borderRadius: 10,
  },
  navButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  tableContainer: {
    paddingHorizontal: 20,
  },
  tableRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderColor: 'black',
  },
  tableHeader: {
    fontWeight: 'bold',
    color: 'black',
    width: 100,
  },
  tableCell: {
    color: 'black',
    width: 100,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginLeft: 10,
  },
  icon: {
    marginHorizontal: 10,
  }
});
