import React, { useEffect, useState } from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { View, Text, TouchableOpacity, StyleSheet, StatusBar, ScrollView, ActivityIndicator  } from 'react-native';
import { useFonts } from 'expo-font';
import AddBookScreen from './AddBookScreen.js';  
import HomeScreen from './HomeScreen.tsx';


const Stack = createStackNavigator();

export default function App() {
  // Load the Gothic font (Cinzel)
  let [fontsLoaded] = useFonts({
    'Cinzel': require('../assets/fonts/Cinzel-VariableFont_wght.ttf'),
  });

  if (!fontsLoaded) {
    return <Text>Loading Fonts...</Text>;
  }

  return (
      <Stack.Navigator initialRouteName="Home">
        {/* Home Screen */}
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: 'Home' }}
        />
        
        {/* Add Book Form Screen */}
        <Stack.Screen
          name="AddBook"
          component={AddBookScreen}
          options={{ title: 'Add a New Book' }}
        />
      </Stack.Navigator>
  );
}

// Styles for the screens
const styles = StyleSheet.create({
container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 50,
    paddingHorizontal: 20,
    },
  topBar: {
    height: 120,
    backgroundColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1,
  },
  title: {
    fontFamily: 'Cinzel',
    fontSize: 64,
    fontWeight: 'bold',
    color: '#fff',
  },
  content: {
    paddingTop: 140,
    paddingBottom: 20,
    alignItems: 'center',
  },
  bottomNav: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 70,
    backgroundColor: '#333',
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  navButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#333',
    borderRadius: 10,
  },
  navButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  tableContainer: {
    paddingHorizontal: 20,
  },
  tableRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderColor: 'black',
  },
  tableHeader: {
    fontWeight: 'bold',
    color: 'black',
    width: 100,
  },
  tableCell: {
    color: 'black',
    width: 100,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginLeft: 10,
  },
  icon: {
    marginHorizontal: 10,
  }
});
