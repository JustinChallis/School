import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

interface AlertButtonProps {
  message: string;
  type: 'success' | 'error'; // Success (green) or error (red)
  onPress: () => void; // Action to trigger on button press
}

const AlertButton: React.FC<AlertButtonProps> = ({ message, type, onPress }) => {
  return (
    <TouchableOpacity
      style={[styles.button, type === 'success' ? styles.successButton : styles.errorButton]}
      onPress={onPress}
    >
      <Text style={[styles.buttonText, type === 'success' ? styles.successText : styles.errorText]}>
        {message}
      </Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginTop: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  successButton: {
    backgroundColor: 'green',
  },
  errorButton: {
    backgroundColor: 'red',
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'white',
  },
  successText: {
    color: 'white',
  },
  errorText: {
    color: 'white',
  },
});

export default AlertButton;
