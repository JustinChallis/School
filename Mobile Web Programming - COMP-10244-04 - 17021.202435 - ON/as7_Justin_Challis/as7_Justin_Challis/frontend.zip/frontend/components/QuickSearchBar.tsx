import React, { useState } from 'react';
import { View, TextInput, StyleSheet, TouchableOpacity, Text } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import axios from 'axios';

export function QuickSearchBar() {
  const [searchText, setSearchText] = useState('');

  const handleSearch = async (id: string) => {
    try {
      const response = await axios.get('http://localhost:3001/books/'+id);
      if (response) {
        alert(response.data.title + " is in stock •ᴗ•");
      } else {
        alert("ID invalid ... we can't find the book you're looking for ( • ᴖ • ｡)");
      }
    } catch (err) {
        alert("ID invalid ... we can't find the book you're looking for ( • ᴖ • ｡)");
        console.error(err);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.searchBar}>
        <MaterialIcons name="search" size={20} color="#888" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Enter ID"
          placeholderTextColor="#888"
          value={searchText}
          onChangeText={setSearchText}
        />
        <TouchableOpacity style={styles.button} onPress={() => handleSearch(searchText)}>
          <Text style={styles.buttonText}>Search</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 10,
    marginTop: 20,
  },
  searchBar: {
    flexDirection: 'row', // Arrange icon, text input, and button horizontally
    alignItems: 'center', // Vertically center the content
    backgroundColor: '#f0f0f0', // Light background color
    borderRadius: 25, // Rounded corners for the search bar
    paddingHorizontal: 15,
    paddingVertical: 10,
  },
  icon: {
    marginRight: 10, // Space between the icon and input field
  },
  input: {
    flex: 1, // Take up the remaining space in the container
    height: 40,
    fontSize: 16,
    color: '#333', // Text color
  },
  button: {
    backgroundColor: '#4CAF50', // Green background for the button
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    marginLeft: 10, // Adds space between the input and the button
  },
  buttonText: {
    color: '#fff', // White text color
    fontSize: 16,
    fontWeight: 'bold',
  },
});
