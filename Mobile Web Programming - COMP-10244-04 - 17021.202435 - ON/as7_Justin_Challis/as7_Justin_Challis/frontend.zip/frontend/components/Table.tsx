import React, { PropsWithChildren, useEffect, useState } from 'react';
import { MaterialIcons } from '@expo/vector-icons';
import { View, Text, StyleSheet, StatusBar,TouchableOpacity, SafeAreaView, ScrollView,  ActivityIndicator } from 'react-native';
import axios from 'axios';
import { useNavigation, ParamListBase } from '@react-navigation/native';
import {StackNavigationProp} from '@react-navigation/stack';

// Define a type for the user data
interface Book {
    id: number;
    isbn: string;
    title: string;
    author: string;
    desc: string;
    genre: string;
  }
  
  const handleDeleteAll = () => {
    axios
    .delete('http://localhost:3001/books/')
    .then((response) => {
  }).catch((error) => {
    // Handle error
    console.log(error);
  });
  
  };
  
  const handleDelete = ({id}: Book) => {
    axios
    .delete('http://localhost:3001/books/'+id)
    .then((response) => {
  }).catch((error) => {
    // Handle error
    console.log(error);
  });
  
  };

export function Table() {
    const navigation = useNavigation<StackNavigationProp<ParamListBase>>();
    const [data, setData] = useState<Book[]>([]);
    const [loading, setLoading] = useState(true);
  
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:3001/books');
        setData(response.data); // Set data in state
      } catch (err) {
        console.error(err);
      }
    };
  
    useEffect(() => {
      fetchData(); // Initial fetch
      setLoading(false);
    // Set interval to fetch every 0.5 seconds
    const intervalId = setInterval(fetchData, 500); // Regular interval
    
    // Cleanup the interval on component unmount
    return () => clearInterval(intervalId);
    }, []);

     return (
          <ScrollView contentContainerStyle={styles.tableContainer}>
          <View style={styles.tableRow}>
            <Text style={styles.tableHeader}>ID</Text>
            <Text style={styles.tableHeader}>ISBN</Text>
            <Text style={styles.tableHeader}>Title</Text>
            <Text style={styles.tableHeader}>Author</Text>
            <Text style={styles.tableHeader}>Description</Text>
            <Text style={styles.tableHeader}>Genre</Text>
            <Text style={styles.tableHeader}></Text>
          </View>
    
          {data.map((item) => (
              <View key={item.id} style={styles.tableRow}>
                <Text style={styles.tableCell}>{item.id}</Text>
                <Text style={styles.tableCell}>{item.isbn}</Text>
                <Text style={styles.tableCell}>{item.title}</Text>
                <Text style={styles.tableCell}>{item.author}</Text>
                <Text style={styles.tableCell}>{item.desc}</Text>
                <Text style={styles.tableCell}>{item.genre}</Text>
                <View style={styles.actions}>
                {/* <TouchableOpacity onPress={() => navigation.navigate('add', {itemId: item.id})}>
                  <MaterialIcons  name="edit" size={24} color="#333" style={styles.icon} />
                </TouchableOpacity> */}
    
                <TouchableOpacity onPress={() => handleDelete(item)}>
                  <MaterialIcons  name="delete" size={24} color="#333" style={styles.icon} />
                </TouchableOpacity>
              </View>
            </View>    
          ))}
              
              <View style={styles.container}>
                      <TouchableOpacity style={styles.button} onPress={handleDeleteAll}>
                        <Text style={styles.contentText}>Delete All</Text>
                      </TouchableOpacity>
                    </View>
        </ScrollView>
      );


}

const styles = StyleSheet.create({
    container: {
        flex: 1,
      },
      topBar: {
        height: 80, // Height of the top bar
        backgroundColor: '#333', // Customize color as needed
        justifyContent: 'center', // Centers content vertically
        alignItems: 'center', // Centers content horizontally
        position: 'absolute', // Fix the bar to the top
        top: 0, // Ensures it's positioned at the top of the screen
        left: 0,
        right: 0,
        zIndex: 1, // Makes sure it's above other components
      },
      title: {
        fontFamily: 'Cinzel',
        fontSize: 32, // Large font size
        fontWeight: 'bold',
        color: '#fff', // White color for the title
      },
      content: {
        paddingTop: 100, // Space for the fixed top bar
        padding: 20,
      },
      contentText: {
        fontSize: 18,
        color: '#333',
      },
      icon: {
        marginHorizontal: 10,
      },
      button: {
        alignItems: 'center',
        backgroundColor: '#DDDDDD',
        padding: 10,
      },
    heading: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  tableContainer: {
    paddingHorizontal: 20,
  },
  tableRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderColor: 'black',
  },
  tableHeader: {
    fontWeight: 'bold',
    color: 'black',
    width: 100,
  },
  tableCell: {
    color: 'black',
    width: 100,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginLeft: 10,
  },
});
